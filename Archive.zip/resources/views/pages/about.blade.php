@extends('layout.app')

@section('content')
    <h1 class="text-center">About Us</h1>
    <div class="d-flex justify-content-center">
        <br>
        <p>This website allows you to create your post/articles. It also allows you to upload picture with the article.
            To create the post you have to register with us and you will be allowed to access the dashboard where you can
            manage your post.
        </p>
    </div>
@endsection