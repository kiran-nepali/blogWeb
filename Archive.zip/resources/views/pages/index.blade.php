@extends('layout.app')

@section('content')
    <h1 class="index-title">{{$title??'Welcome to Your Blog'}}</h1>
@endsection
