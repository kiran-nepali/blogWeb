<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- JavaScript Bundle with Popper -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
        
        
        <script src="//cdn.ckeditor.com/4.16.0/standard/ckeditor.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">
        <title><?php echo e(config('app.name','BlogWeb')); ?></title>

    </head>
    <body>
        <?php echo $__env->make('nav.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="container">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        <script src="<?php echo e(asset('ckeditor/ckeditor.js')); ?>"></script>
        <script>
            CKEDITOR.replace( 'article-ckeditor' );
        </script>   
    </body>
</html>
<?php /**PATH /Users/kiran/Desktop/laravel/blog/resources/views/layout/app.blade.php ENDPATH**/ ?>