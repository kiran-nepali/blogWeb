<?php $__env->startSection('content'); ?>
    <h1 class="index-title">Posts</h1>
    <br>
    <h2><?php echo e($post->title); ?></h2>
    <small><?php echo e($post->created_at); ?>  by <?php echo e($post->user->name); ?></small>
    <br>
    <div>
        <img style="width:100%" src="/storage/cover_images/<?php echo e($post->cover_image); ?>" alt="">
        <?php echo $post->body; ?>

    </div>
    <hr>
    <hr>
    <?php if(!Auth::guest()): ?>
        <?php if(Auth::user()->id == $post->user_id): ?>
            <a href="/posts/<?php echo e($post->id); ?>/edit" class="btn btn-primary">Edit</a>

            <?php echo Form::open(['action' => ['App\Http\Controllers\PostsController@destroy',$post->id],'method'=>'DELETE','class'=>'float-right']); ?>

            <?php echo e(Form::submit('Delete',['class'=>'btn btn-danger'])); ?>

            <?php echo Form::close(); ?>

        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/kiran/Desktop/laravel/blog/resources/views/posts/singlepost.blade.php ENDPATH**/ ?>