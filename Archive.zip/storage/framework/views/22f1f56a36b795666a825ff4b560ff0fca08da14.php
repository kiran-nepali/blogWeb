<?php $__env->startSection('content'); ?>
    <h1 class="text-center">About Us</h1>
    <div class="d-flex justify-content-center">
        <br>
        <p>This website allows you to create your post/articles. It also allows you to upload picture with the article.
            To create the post you have to register with us and you will be allowed to access the dashboard where you can
            manage the post.
        </p>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/kiran/Desktop/laravel/blog/resources/views/pages/about.blade.php ENDPATH**/ ?>