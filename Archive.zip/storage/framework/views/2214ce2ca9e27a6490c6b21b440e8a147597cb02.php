<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="/"><?php echo e(config('app.name')); ?></a>
  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item ">
        <a class="nav-link" href="/">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/about">About</a>
      </li>
    </ul>
    <ul class="navbar-nav ms-auto">
      <?php if(auth()->guard()->check()): ?>
      <li class="nav-item">
        <div class="dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
            <?php echo e(Auth::user()->username); ?>

          </a>
        
          <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
            <li><a class="dropdown-item" href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
          </ul>
        </div>        
        
      </li>
      <li class="nav-item">
        <form action="<?php echo e(route('logout')); ?>" method="post" class="inline">
          <?php echo csrf_field(); ?>
            <button type="submit" class="p-2 btn btn-outline-* text-light">Logout</button>
        </form>
      </li>
      <?php endif; ?>
      <?php if(auth()->guard()->guest()): ?>
      <li class="nav-item">
        <a href="<?php echo e(route('login')); ?>" class="nav-link">Login</a>
      </li>
      <li class="nav-item">
        <a href="<?php echo e(route('register')); ?>" class="nav-link">Register</a>
      </li>
      <?php endif; ?>
    </ul>
    
  </div>
</nav>

  

  <?php /**PATH /Users/kiran/Desktop/laravel/blog/resources/views/nav/navbar.blade.php ENDPATH**/ ?>