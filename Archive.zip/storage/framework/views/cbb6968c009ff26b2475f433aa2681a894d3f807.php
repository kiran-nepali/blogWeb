<?php $__env->startSection('content'); ?>
    <h1 class="index-title"><?php echo e($title??'Welcome to Your Blog'); ?></h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/kiran/Desktop/laravel/blog/resources/views/pages/index.blade.php ENDPATH**/ ?>