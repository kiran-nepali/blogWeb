<?php $__env->startSection('content'); ?>
   <div class="card mt-3 text-center">
      <div class="card-header">
         <h3>Dashboard</h3> 
      </div>
      <div class="card-body">
      <h5 class="card-title">You're logged in !!</h5>
      <p class="card-text">Create Your New Post here</p>
      <a href="/posts/create" class="btn btn-primary" style="width: 14rem;">Create</a>
      </div>
      <div class="card-footer text-muted">
      </div>
   </div>
   <br>
   <br>
   <hr>
   <div class="d-flex justify-content-center mt-10rem">
      <table class="table  table-striped table-hover text-center" style="width:25rem;">
         <thead>
            <tr>
               <th scope="col">Title</th>
            </tr>
         </thead>
         <tbody>
            <?php if($posts->count()): ?>
               <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <tr>
                  <td><?php echo e($post->title); ?></td>
                  <td><a href="/posts/<?php echo e($post->id); ?>/edit"><i class="fas fa-user-edit"></i></a>
                  </td>
                  <td><?php echo Form::open(['action' => ['App\Http\Controllers\PostsController@destroy',$post->id],'method'=>'DELETE','class'=>'float-right']); ?>

                     <?php echo e(Form::button('<i class="fa fa-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-sm'] )); ?>

                     <?php echo Form::close(); ?></td>
               </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
               <h4>There are no post</h4>
            <?php endif; ?>
         </tbody>
       </table>
   </div>   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/kiran/Desktop/laravel/blog/resources/views/dashboard.blade.php ENDPATH**/ ?>